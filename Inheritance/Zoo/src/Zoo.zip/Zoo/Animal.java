package Zoo;

public class Animal {
    protected String name;

    public Animal(String name) {
        this.name = name;
    }

    protected String getName() {
        return name;
    }
}
