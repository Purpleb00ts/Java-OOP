public class Motorcycle extends Vehicle{
    protected Motorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }
}
