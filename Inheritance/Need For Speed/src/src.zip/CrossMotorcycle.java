public class CrossMotorcycle extends Motorcycle{
    protected CrossMotorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }
}
