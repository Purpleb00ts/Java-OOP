public class FamilyCar extends Car{
    protected FamilyCar(double fuel, int horsePower) {
        super(fuel, horsePower);
    }
}
