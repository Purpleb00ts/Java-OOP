package Hero;

public class Main {
    public static void main(String[] args) {
        MuseElf museElf = new MuseElf("Konchita", 69);
        Elf elf = new Elf("123", 53);
        BladeKnight bladeKnight = new BladeKnight("Mcconel", 79);
        Wizard wizard = new Wizard("123", 13);
        Hero hero = new Hero("Kaloyan", 99999);

        System.out.println(museElf);
        System.out.println(elf);
        System.out.println(bladeKnight);
        System.out.println(hero);
    }
}
