import java.text.DecimalFormat;

public class Car extends Vehicle{

    public Car(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption);
    }

    @Override
    public void driving(double distance) {
        double requiredFuel = (this.fuelConsumption + 0.9) * distance;
        DecimalFormat df = new DecimalFormat("#.##");
        if(this.fuelQuantity >= requiredFuel){
            this.fuelQuantity -= requiredFuel;
            System.out.println("Car travelled " + df.format(distance) + " km");
        } else {
            System.out.println("Car needs refueling");
        }
    }

    @Override
    public void refueling(double fuel) {
        this.fuelQuantity += fuel;
    }

    @Override
    public String toString() {
        return String.format("Car: %.2f", this.fuelQuantity);
    }
}
