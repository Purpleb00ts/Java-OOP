import java.text.DecimalFormat;

public class Truck extends Vehicle{

    public Truck(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption);
    }
    @Override
    public void driving(double distance) {
        double requiredFuel = (this.fuelConsumption + 1.6) * distance;
        DecimalFormat df = new DecimalFormat("#.##");
        if(this.fuelQuantity >= requiredFuel){
            this.fuelQuantity -= requiredFuel;
            System.out.println("Truck travelled " + df.format(distance) + " km");
        } else {
            System.out.println("Truck needs refueling");
        }
    }

    @Override
    public void refueling(double fuel) {
        this.fuelQuantity += fuel * 0.95;
    }

    @Override
    public String toString() {
        return String.format("Truck: %.2f", this.fuelQuantity);
    }
}
