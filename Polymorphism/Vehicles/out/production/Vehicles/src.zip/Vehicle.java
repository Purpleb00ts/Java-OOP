public abstract class Vehicle {

    protected double fuelQuantity;

    protected double fuelConsumption;

    protected Vehicle(double fuelQuantity, double fuelConsumption) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumption = fuelConsumption;
    }

    public abstract void driving(double distance);

    public abstract void refueling(double fuel);

    @Override
    public abstract String toString();
}
