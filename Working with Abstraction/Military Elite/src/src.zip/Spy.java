public interface Spy {
    String getCodeNumber();
    String toString();
}
