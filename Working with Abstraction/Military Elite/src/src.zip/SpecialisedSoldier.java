public interface SpecialisedSoldier {
    String getCorpsType();
}
