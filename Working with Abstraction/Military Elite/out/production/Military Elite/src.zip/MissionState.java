public enum MissionState {
    inProgress,
    finished
}
