public interface Private {
    double getSalary();
    int getId();
    String getFirstName();
    String getLastName();

    String toString();
}
